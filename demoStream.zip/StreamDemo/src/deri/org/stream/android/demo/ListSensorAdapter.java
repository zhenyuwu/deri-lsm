package deri.org.stream.android.demo;

import java.util.ArrayList;

import deri.org.stream.android.demo.ListSensorXMLParser.Sensor;



import android.app.Activity;
import android.content.Context;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class ListSensorAdapter extends BaseAdapter{
	private Activity	activity;
	private ArrayList<Sensor> sensorList;
	private	static LayoutInflater inflater	=	null;
	
	public ListSensorAdapter(Activity a, ArrayList<Sensor> sensorList){
		activity	=	a;
		this.sensorList	=	sensorList;
		inflater 	= 	(LayoutInflater)activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
	}
		
	@Override
	public int getCount() {
		return sensorList.size();
	}

	@Override
	public Object getItem(int position) {
		return position;
	}

	@Override
	public long getItemId(int position) {
		return position;
	}
	
	public static class ViewHolder{
		public TextView	name;
		public TextView type;
		public TextView distance;
		public ImageView image;
	}


	public View getView(int position, View convertView, ViewGroup parent) {
		View	vi	=	convertView;
		ViewHolder holder;
		
		if(convertView	==	null){
			vi		=	inflater.inflate(R.layout.sensoritem, null);
			holder	=	new ViewHolder();
			
			holder.name	= (TextView)vi.findViewById(R.id.sensorNameId);
			holder.type	= (TextView)vi.findViewById(R.id.sensorTypeId);
			holder.distance	=	(TextView)vi.findViewById(R.id.sensorDistanceId);
			holder.image	=	(ImageView)vi.findViewById(R.id.image);
			vi.setTag(holder);
		
		}else
			holder	=	(ViewHolder)vi.getTag();
		
			holder.name.setText(sensorList.get(position).getSensorName());
			holder.type.setText("Type: "+ sensorList.get(position).getSensorType());
			holder.distance.setText("Distance: " + sensorList.get(position).getSensorDistance());
			
			if (sensorList.get(position).getSensorType().equals("bikehire")){
			holder.image.setImageResource(R.drawable.icon_bikehire);
			}else if (sensorList.get(position).getSensorType().equals("railwaystation")){
			holder.image.setImageResource(R.drawable.icon_railwaystation);
			}else if (sensorList.get(position).getSensorType().equals("traffic")){
			holder.image.setImageResource(R.drawable.icon_traffic);
			}else if (sensorList.get(position).getSensorType().equals("weather")){
			holder.image.setImageResource(R.drawable.icon_weather);
			}else if (sensorList.get(position).getSensorType().equals("webcam")){
			holder.image.setImageResource(R.drawable.icon_webcam);
			}else if (sensorList.get(position).getSensorType().equals("airport")){
			holder.image.setImageResource(R.drawable.icon_airport);
			}else if (sensorList.get(position).getSensorType().equals("sealevel")){
			holder.image.setImageResource(R.drawable.icon_sealevel);
			}else if (sensorList.get(position).getSensorType().equals("snowfall")){
			holder.image.setImageResource(R.drawable.icon_snowfall);
			}else if (sensorList.get(position).getSensorType().equals("snowdepth")){
			holder.image.setImageResource(R.drawable.icon_snowdepth);
			}else{
				holder.image.setImageResource(R.drawable.icon);	
			}
		
		return vi;
	}
}
