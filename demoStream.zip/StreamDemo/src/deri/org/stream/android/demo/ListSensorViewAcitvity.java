package deri.org.stream.android.demo;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

public class ListSensorViewAcitvity extends Activity{
	TextView latitude,longtitude;
	private ListView	sensorListlv;
	private ListSensorXMLParser sXP;
	 private  ListSensorAdapter sensorAdapter;
	
	@Override
	public void onCreate(Bundle savedInstanceState){
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		
		String sLatitude	=	(String)(getIntent().getExtras().getString("latitude"));
		String sLongtitude	=	(String)(getIntent().getExtras().getString("longtitude"));
	
		sensorListlv	=	(ListView)findViewById(R.id.SensorListViewId);
     	sensorListlv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
     		@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int position, long arg3) {
     			Intent i = new Intent(ListSensorViewAcitvity.this,SensorViewActivity.class);
     			i.putExtra("dataUrl", sXP.sensorList.get(position).getSensorURL());
     			startActivity(i);
      		}
     	});
      
     	String url = "http://140.203.155.176:8080/sensormiddleware/lsmfeed?api=discover&usrId=31865017465746" +
     				 "&lat="  + sLatitude +
     				 "&long=" +	sLongtitude;
		
     	sXP	=	new ListSensorXMLParser(url);
		sensorAdapter = new ListSensorAdapter(ListSensorViewAcitvity.this, sXP.sensorList);
	    sensorListlv.setAdapter(sensorAdapter);
     }
	
}
