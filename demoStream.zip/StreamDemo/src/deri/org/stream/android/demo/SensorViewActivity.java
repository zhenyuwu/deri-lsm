package deri.org.stream.android.demo;

import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;

import android.app.Activity;
import android.app.Dialog;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

public class SensorViewActivity extends Activity {
//	TextView latitude,longtitude;
	ListView  propertyListlv;
	ListPropertyAdapter propertyAdapter;
	SensorXMLParser sXP;
	
	String ImageURL;
	
	final static String DEBUG	=	"System.out";
	@Override
	public void onCreate(Bundle savedInstanceState){
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		String dataUrl	=	(String)(getIntent().getExtras().getString("dataUrl"));
		
		Log.d(DEBUG,dataUrl);
		
//		latitude 	=	(TextView)findViewById(R.id.latitude);
//        longtitude	=	(TextView)findViewById(R.id.longtitude);
        
        
        
        sXP	=	new SensorXMLParser(dataUrl);
        propertyListlv	=	(ListView)findViewById(R.id.SensorListViewId);
       
        propertyAdapter = new ListPropertyAdapter(this, sXP.propertiesList);
        propertyListlv.setAdapter(propertyAdapter);
        
        propertyListlv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			
        	@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int position,long arg3) {
			   if (sXP.propertiesList.get(position).getName().equals("Picture:  "))
				   if (!sXP.propertiesList.get(position).getValue().contains("webcams"))
			   {
			   ImageURL= sXP.propertiesList.get(position).getValue();
				   showDialog(1);
			   }			
			}
		});
    }
	
	protected Dialog onCreateDialog(int id){
		Dialog dialog;
		switch(id){
		case 1:
		
			dialog	=	new Dialog(SensorViewActivity.this);
			dialog.setTitle("Picture");
			dialog.setContentView(R.layout.image);
			ImageView iv	=	(ImageView)dialog.findViewById(R.id.photo);
			try {
				Drawable a = Drawable.createFromStream((InputStream) new URL(ImageURL).getContent(),"photo");
				if (a!=null) iv.setImageDrawable(a);
			} catch (MalformedURLException e) {e.printStackTrace();
			} catch (IOException e) {e.printStackTrace();}
			
			Button ok	=	(Button)dialog.findViewById(R.id.ok);
			ok.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View arg0) {
					dismissDialog(1);
				}
			} );
			break;
		default:
			dialog = null;
		}
		return dialog;
	}
    
}
