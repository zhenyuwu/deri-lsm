package deri.org.stream.android.demo;


import com.google.android.maps.MapActivity;
import com.google.android.maps.MapController;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

public class StreamDemoActivity extends MapActivity {
    /** Called when the activity is first created. */
    TextView latitude,longtitude;
    private   	MapController mController;
    private		StreamDemoMapView mapView;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.map);
//        latitude 	=	(TextView)findViewById(R.id.latitude);
//        longtitude	=	(TextView)findViewById(R.id.longtitude);
       
        mapView 	=	(StreamDemoMapView)findViewById(R.id.mapview);
//        mapView.set(latitude, longtitude);
        mapView.setBuiltInZoomControls(true);
        mController	=	mapView.getController();
        mController.setZoom(16);
        SensorOverLay.setAct(StreamDemoActivity.this);
//        Button Go	=	(Button)findViewById(R.id.buttonView);
        
//        Go.setOnClickListener(new OnClickListener(){
//			@Override
//			public void onClick(View arg0) { 
//				Intent i	=	new Intent(StreamDemoActivity.this,ListSensorViewAcitvity.class);
//				i.putExtra("latitude", Double.toString(mapView.getMapCenter().getLatitudeE6()/1E6));
//				i.putExtra("longtitude", Double.toString(mapView.getMapCenter().getLongitudeE6()/1E6));
//				startActivity(i);
//			}});
    
    }
    
    @Override
	protected boolean isRouteDisplayed(){
		return false;
	} 
}