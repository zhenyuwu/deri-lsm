package deri.org.stream.android.demo;

//import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import android.util.Log;

public class ListSensorXMLParser {
    public final static String DEBUG = "ListSensorXMLParser"; 
	
	public ArrayList <Sensor> sensorList;
	
	
	public ListSensorXMLParser(String url){
		 DocumentBuilderFactory builderFactory	=	DocumentBuilderFactory.newInstance();
	  	 try {
			 	sensorList	=	new ArrayList<Sensor>();
		
			 	URL Url	=	new URL(url);
			 	
				DocumentBuilder builder				=	builderFactory.newDocumentBuilder();
				Document document					=	builder.parse(Url.openStream());
				document.getDocumentElement().normalize();
				Element rootElement							=	document.getDocumentElement();
				NodeList nodesSensor						=	rootElement.getChildNodes();
		    
		        
		        for (int i=0; i< nodesSensor.getLength(); i++){
		        	String name = "";
		        	String type = "";
		        	String distance = "";
		        	String dataURL  = "";
		        	String lat		= "";
		        	String lon		= "";
		        	NodeList child = nodesSensor.item(i).getChildNodes();
		        	//==================================
		        	for (int j = 0; j<child.getLength();j++){
		        		if (child.item(j).getNodeName().equals("name")) {
		        			name = child.item(j).getFirstChild().getNodeValue();
		        			Log.d(DEBUG,name);
		        		}
		        		if (child.item(j).getNodeName().equals("type")) {
		        			type = child.item(j).getFirstChild().getNodeValue();
		        			Log.d(DEBUG,type);
		        		}
		        		if (child.item(j).getNodeName().equals("distance")) {
		        			distance = child.item(j).getFirstChild().getNodeValue();
		        			Log.d(DEBUG,distance);
		        		}
		        		if (child.item(j).getNodeName().equals("dataURL")) {
		        			dataURL = child.item(j).getFirstChild().getNodeValue();
		        			Log.d(DEBUG,dataURL);
		        		}
		        		
		        		if (child.item(j).getNodeName().equals("latitude")) {
		        			lat = child.item(j).getFirstChild().getNodeValue();
		        			Log.d(DEBUG,dataURL);
		        		}
		        		
		        		if (child.item(j).getNodeName().equals("longitude")) {
		        			lon = child.item(j).getFirstChild().getNodeValue();
		        			Log.d(DEBUG,dataURL);
		        		}
		        	}
		        	
		        	Sensor sensor= new Sensor(name,type,distance,dataURL,lat, lon);
		        	sensorList.add(sensor);
		        }
		} catch (ParserConfigurationException e) {
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (SAXException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public class Sensor{
		private String name;
		private String type;
		private String distance;
		private String dataURL;
		private int lon;
		private int lat;
		
		public Sensor(String name, String type, String distance,String dataURL,String lat,String lon){
			this.name 	= name;
			this.type	= type;
			this.distance	=	distance;
			this.dataURL	=	dataURL;
			this.lat		=	(int)(Double.parseDouble(lat)*1e6);
			this.lon		=	(int)(Double.parseDouble(lon)*1e6);
		}
		
		public String getSensorName()		{return name;}
		public String getSensorType()		{return type;}
		public String getSensorDistance()	{return distance;}
		public String getSensorURL()		{return dataURL;}
		public int getLat()				{return lat;}
		public int getLon()				{return lon;}
	}
}
