package deri.org.stream.android.demo;

import java.util.ArrayList;

import deri.org.stream.android.demo.SensorXMLParser.Property;

import android.app.Activity;
import android.content.Context;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class ListPropertyAdapter extends BaseAdapter{
	private Activity	activity;
	private ArrayList<Property> propertyList;
	private	static LayoutInflater inflater	=	null;
	
	public ListPropertyAdapter(Activity a, ArrayList<Property> propertyList){
		activity	=	a;
		this.propertyList	=	propertyList;
		inflater 	= 	(LayoutInflater)activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
	}
		
	@Override
	public int getCount() {
		return propertyList.size();
	}

	@Override
	public Object getItem(int position) {
		return position;
	}

	@Override
	public long getItemId(int position) {
		return position;
	}
	
	public static class ViewHolder{
		public TextView	name;
		public TextView value;
	}


	public View getView(int position, View convertView, ViewGroup parent) {
		View	vi	=	convertView;
		ViewHolder holder;
		
		if(convertView	==	null){
			vi		=	inflater.inflate(R.layout.propertyitem, null);
			holder	=	new ViewHolder();
			
			holder.name	= (TextView)vi.findViewById(R.id.propertyNameId);
			holder.value	= (TextView)vi.findViewById(R.id.propertyValueId);
			vi.setTag(holder);
		}else
			holder	=	(ViewHolder)vi.getTag();
		
			holder.name.setText(propertyList.get(position).getName());
			holder.value.setText(propertyList.get(position).getValue());
			
		
		return vi;
	}
}
