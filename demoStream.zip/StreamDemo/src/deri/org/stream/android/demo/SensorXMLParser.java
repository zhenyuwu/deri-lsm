package deri.org.stream.android.demo;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import android.util.Log;

public class SensorXMLParser {
    public final static String DEBUG = "System.out"; 
	
	public ArrayList <Property> propertiesList;
	public String id;
	public String type;
	
	public SensorXMLParser(String url){
		 DocumentBuilderFactory builderFactory	=	DocumentBuilderFactory.newInstance();
	   
		 try {
			 	propertiesList	=	new ArrayList<Property>();
				
			 	URL Url	=	new URL(url);
			 	
				DocumentBuilder builder				=	builderFactory.newDocumentBuilder();
				Document document					=	builder.parse(Url.openStream());
				document.getDocumentElement().normalize();
				Element rootElement							=	document.getDocumentElement();
				NodeList nodesSensor						=	rootElement.getChildNodes();
		    
		       	id 		= ((Element)nodesSensor.item(0)).getAttribute("id");
		        Log.d(DEBUG, id);
		       	
		        type 		= ((Element)nodesSensor.item(0)).getAttribute("type");
		        Log.d(DEBUG, type);
		    	
		        if (!type.equals("railwaystation")){
		        	NodeList propertyNodes 	=	nodesSensor.item(0).getChildNodes();
		        	for (int i=0; i<propertyNodes.getLength(); i++){
		        		String name;
		        		String value;
		    			
		        		name		  = ((Element)propertyNodes.item(i)).getAttribute("name");
		        		Log.d(DEBUG,name);
		    		
		        		if (propertyNodes.item(i).getFirstChild().hasChildNodes()){
		        			value		  = propertyNodes.item(i).getFirstChild().getFirstChild().getNodeValue();	
		        			if (value!=null) {
		        				Log.d(DEBUG,value);
		        				propertiesList.add(new Property(name+ ":  ",value));
		        			}
		        		}
		        	}
		        }else{
		        	NodeList Train 	=	nodesSensor.item(0).getChildNodes();
		        	for (int j=0; j<Train.getLength(); j++){
		        		NodeList propertyNodes	=	Train.item(j).getChildNodes();
		        		
		        		for (int i=0; i<propertyNodes.getLength(); i++){
		        		
		        			String name;
		        			String value;
		    			
		        			name		  = ((Element)propertyNodes.item(i)).getAttribute("name");
		        			Log.d(DEBUG,name);
		    		
		        			if (propertyNodes.item(i).getFirstChild().hasChildNodes()){
		        				value		  = propertyNodes.item(i).getFirstChild().getFirstChild().getNodeValue();	
		        					if (value!=null) {
		        						Log.d(DEBUG,value);
		        						propertiesList.add(new Property(name + ":  ",value));
		        					}
		        			}
		        		}
		        		
		        		propertiesList.add(new Property("================================================",""));
		        	}
		        }
		} catch (ParserConfigurationException e) {
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (SAXException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	
	public class Property{
		private String name;
		private String value;
		
		public Property(String name, String value){
			this.name	=	name;
			this.value	=	value;
		}
		
		public String getName(){return name;}
		public String getValue(){return value;}
	}
}
