package deri.org.stream.android.demo;

import java.util.ArrayList;

import android.app.Activity;
import android.content.Intent;
import android.graphics.drawable.Drawable;

import com.google.android.maps.ItemizedOverlay;
import com.google.android.maps.OverlayItem;

public class SensorOverLay extends ItemizedOverlay<OverlayItem>{
	String url;
	
	private ArrayList<OverlayItem> mapOverlays = new ArrayList<OverlayItem>();
	
	private static Activity activity;
	
	public static void setAct(Activity	act){
		activity	=	act;
	}
	
	public SensorOverLay(Drawable defaultMarker) {
		  super(boundCenterBottom(defaultMarker));
	}
	
	public SensorOverLay(Drawable defaultMarker, String url) {
		  this(defaultMarker);
		  this.url	=	url;
	}

	@Override
	protected OverlayItem createItem(int i) {
		return mapOverlays.get(i);
	}

	@Override
	public int size() {
		return mapOverlays.size();
	}
	
	@Override
	protected boolean onTap(int index) {
		Intent i = new Intent(activity,SensorViewActivity.class);
		i.putExtra("dataUrl", url);
		activity.startActivity(i);
		return true;
	}
	
	public void addOverlay(OverlayItem overlay) {
		mapOverlays.add(overlay);
	    this.populate();
	}
	
}
