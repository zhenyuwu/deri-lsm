package deri.org.stream.android.demo;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.util.Log;
import com.google.android.maps.GeoPoint;
import com.google.android.maps.MapView;
import com.google.android.maps.OverlayItem;

import deri.org.stream.android.demo.ListSensorXMLParser.Sensor;

public class StreamDemoMapView extends MapView{
//	TextView latitude,longtitude;
	String latitudeS,longtitudeS;
	
	public StreamDemoMapView(Context arg0, AttributeSet arg1) {
		super(arg0, arg1);

	}

	@Override
	public void draw(Canvas canvas){
		getOverlays().clear();
		latitudeS	=	Double.toString(getMapCenter().getLatitudeE6()/1E6);
		longtitudeS	=	Double.toString(getMapCenter().getLongitudeE6()/1E6);
//		latitude.setText("Latitude : " + latitudeS);
//        longtitude.setText("Longtitude : " + longtitudeS);
        
        String url = "http://lsm.deri.ie/lsmfeed?api=discover&usrId=31865017465746" +
		 			 "&lat="  + latitudeS +
		 			 "&long=" +	longtitudeS;
        
        ListSensorXMLParser parser	=	new ListSensorXMLParser(url);
        
        for (int i = 0; i<parser.sensorList.size();i++){
        	Sensor sensor	=	parser.sensorList.get(i);
        	
        	if (sensor.getSensorType().equals("bikehire")){
        		Drawable	drawable	=	getResources().getDrawable(R.drawable.icon_bikehire);
//        		SensorOverLay	sensorOverlay	=	new SensorOverLay(drawable);
        		SensorOverLay	sensorOverlay	=	new SensorOverLay(drawable, sensor.getSensorURL());
        		
        		GeoPoint point	=	new GeoPoint(sensor.getLat(),sensor.getLon());
        		OverlayItem	overlayItem	=	new OverlayItem(point,"","");
        		sensorOverlay.addOverlay(overlayItem);
        		
        		getOverlays().add(sensorOverlay);	
        		Log.d("System.out",point.toString());
        	}
        	
         	if (sensor.getSensorType().equals("railwaystation")){
        		Drawable	drawable	=	getResources().getDrawable(R.drawable.icon_railwaystation);
//        		SensorOverLay	sensorOverlay	=	new SensorOverLay(drawable);
        		SensorOverLay	sensorOverlay	=	new SensorOverLay(drawable, sensor.getSensorURL());
        		
        		GeoPoint point	=	new GeoPoint(sensor.getLat(),sensor.getLon());
        		OverlayItem	overlayItem	=	new OverlayItem(point,"","");
        		sensorOverlay.addOverlay(overlayItem);
        		
        		getOverlays().add(sensorOverlay);	
        		Log.d("System.out",point.toString());
        	}
         	
         	if (sensor.getSensorType().equals("traffic")){
        		Drawable	drawable	=	getResources().getDrawable(R.drawable.icon_traffic);
//        		SensorOverLay	sensorOverlay	=	new SensorOverLay(drawable);
        		SensorOverLay	sensorOverlay	=	new SensorOverLay(drawable, sensor.getSensorURL());
        		
        		GeoPoint point	=	new GeoPoint(sensor.getLat(),sensor.getLon());
        		OverlayItem	overlayItem	=	new OverlayItem(point,"","");
        		sensorOverlay.addOverlay(overlayItem);
        		
        		getOverlays().add(sensorOverlay);	
        		Log.d("System.out",point.toString());
        	}
         	
         	if (sensor.getSensorType().equals("weather")){
        		Drawable	drawable	=	getResources().getDrawable(R.drawable.icon_weather);
//        		SensorOverLay	sensorOverlay	=	new SensorOverLay(drawable);
        		SensorOverLay	sensorOverlay	=	new SensorOverLay(drawable, sensor.getSensorURL());
        		
        		GeoPoint point	=	new GeoPoint(sensor.getLat(),sensor.getLon());
        		OverlayItem	overlayItem	=	new OverlayItem(point,"","");
        		sensorOverlay.addOverlay(overlayItem);
        		
        		getOverlays().add(sensorOverlay);	
        		Log.d("System.out",point.toString());
        	}
         	
         	if (sensor.getSensorType().equals("webcam")){
        		Drawable	drawable	=	getResources().getDrawable(R.drawable.icon_webcam);
//        		SensorOverLay	sensorOverlay	=	new SensorOverLay(drawable);
        		SensorOverLay	sensorOverlay	=	new SensorOverLay(drawable, sensor.getSensorURL());
        		
        		GeoPoint point	=	new GeoPoint(sensor.getLat(),sensor.getLon());
        		OverlayItem	overlayItem	=	new OverlayItem(point,"","");
        		sensorOverlay.addOverlay(overlayItem);
        		
        		getOverlays().add(sensorOverlay);	
        		Log.d("System.out",point.toString());
        	}
         	
        	
         	if (sensor.getSensorType().equals("airport")){
        		Drawable	drawable	=	getResources().getDrawable(R.drawable.icon_airport);
//        		SensorOverLay	sensorOverlay	=	new SensorOverLay(drawable);
        		SensorOverLay	sensorOverlay	=	new SensorOverLay(drawable, sensor.getSensorURL());
        		
        		GeoPoint point	=	new GeoPoint(sensor.getLat(),sensor.getLon());
        		OverlayItem	overlayItem	=	new OverlayItem(point,"","");
        		sensorOverlay.addOverlay(overlayItem);
        		
        		getOverlays().add(sensorOverlay);	
        		Log.d("System.out",point.toString());
        	}
         	
         	
         	if (sensor.getSensorType().equals("sealevel")){
        		Drawable	drawable	=	getResources().getDrawable(R.drawable.icon_sealevel);
//        		SensorOverLay	sensorOverlay	=	new SensorOverLay(drawable);
        		SensorOverLay	sensorOverlay	=	new SensorOverLay(drawable, sensor.getSensorURL());
        		
        		GeoPoint point	=	new GeoPoint(sensor.getLat(),sensor.getLon());
        		OverlayItem	overlayItem	=	new OverlayItem(point,"","");
        		sensorOverlay.addOverlay(overlayItem);
        		
        		getOverlays().add(sensorOverlay);	
        		Log.d("System.out",point.toString());
        	}
         	
         	if (sensor.getSensorType().equals("snowfall")){
        		Drawable	drawable	=	getResources().getDrawable(R.drawable.icon_snowfall);
//        		SensorOverLay	sensorOverlay	=	new SensorOverLay(drawable);
        		SensorOverLay	sensorOverlay	=	new SensorOverLay(drawable, sensor.getSensorURL());
        		
        		GeoPoint point	=	new GeoPoint(sensor.getLat(),sensor.getLon());
        		OverlayItem	overlayItem	=	new OverlayItem(point,"","");
        		sensorOverlay.addOverlay(overlayItem);
        		
        		getOverlays().add(sensorOverlay);	
        		Log.d("System.out",point.toString());
        	}
         	
           	
         	if (sensor.getSensorType().equals("snowdepth")){
        		Drawable	drawable	=	getResources().getDrawable(R.drawable.icon_snowdepth);
//        		SensorOverLay	sensorOverlay	=	new SensorOverLay(drawable);
        		SensorOverLay	sensorOverlay	=	new SensorOverLay(drawable, sensor.getSensorURL());
        		
        		GeoPoint point	=	new GeoPoint(sensor.getLat(),sensor.getLon());
        		OverlayItem	overlayItem	=	new OverlayItem(point,"","");
        		sensorOverlay.addOverlay(overlayItem);
        		
        		getOverlays().add(sensorOverlay);	
        		Log.d("System.out",point.toString());
        	}
         	
        }
        
        
        
        
        
        
        
        super.draw(canvas);
	}
	
//	public void set(TextView latitude, TextView longtitude){
//		this.latitude	=	latitude;
//		this.longtitude	=	longtitude;
//	}
}
